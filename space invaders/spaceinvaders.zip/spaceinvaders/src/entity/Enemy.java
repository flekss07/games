package entity;

import main.KeyHandler;
import main.Main;
import main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Enemy extends entity{
    gamePanel gp;
    KeyHandler keyH;
    private int offSetX, offSetY, waveNum;
    private String imgAddress;
    public Enemy(gamePanel gp)
    {
        this.gp = gp;
        this.keyH = keyH;

        setDefaultValues();
        getEnemyImage();
    }
    public void setDefaultValues() // sets the default values for the enemy
    {
        x = 0;
        y = 0;
        speed = 3;
        offSetX = 0;
        offSetY = 0;
        waveNum = 1;
    }

    public void getEnemyImage() // gets the image of the enemy
    {
        try{
            enemySpaceShip = ImageIO.read(getClass().getResourceAsStream("/entityes/ship_4.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void update() // updates the enemy position
    {
        enemyMovement();
    }
    public void draw(Graphics2D g2) // draws the enemy
    {
        waveDrawer(waveNum,g2);
    }

    private void waveDrawer(int waveNum,Graphics2D g2) // draws a wave of enemies based on the wavenum inserted
    {
        for(int a = 0; a < waveNum; a++) {
            offSetY = a * gp.tileSize; // offsets the other enemies to the right
            for (int i = 0; i < waveNum; i++) {
                offSetX = i * gp.tileSize; // offsets the other enemies to the right
                BufferedImage image = null;
                image = enemySpaceShip;
                g2.drawImage(image, x + offSetX, y + offSetY, gp.tileSize, gp.tileSize, null);
            }
        }
    }
    private void enemyMovement() // makes the enemy move left and right on the map
    {
         // makes the enemy move unthil it reaches half of the screen's height

            x+=speed; // makes the enemy move
            if(x+gp.tileSize + offSetX >= gp.screenWidth)
            {
                speed *= -1;
                if(y+ offSetY < gp.screenHeight/2) // makes the enemy go down when it reaches the border of the window
                    y += gp.tileSize;
            }

            if(x <= 0)
            {
                speed = Math.abs(speed);
                if(y+ offSetY < gp.screenHeight/2) // makes the enemy go down when it reaches the border of the window
                    y+= gp.tileSize;
            }
    }

}
