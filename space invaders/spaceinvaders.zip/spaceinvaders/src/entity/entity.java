package entity;

import java.awt.image.BufferedImage;

public class entity {
    public int x,y;
    public int speed;
    public BufferedImage playerSpaceShip, enemySpaceShip;
    public String ship;
}
