package entity;

import main.gamePanel;
import main.KeyHandler;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class player extends entity{
    gamePanel gp;
    KeyHandler keyH;

    public player(gamePanel gp, KeyHandler keyH)
    {
        this.gp = gp;
        this.keyH = keyH;

        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues()
    {
        x = gp.screenWidth/2- gp.tileSize/2;
        y = gp.screenHeight-gp.tileSize*2;
        speed = 5;
    }
    public void getPlayerImage()
    {
        try{
            playerSpaceShip = ImageIO.read(getClass().getResourceAsStream("/entityes/ship_5.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void update() // updates the player's position based on what keys are pressed
    {
        keyUpdate();
        PlayerBorderCollision();
    }
    public void draw(Graphics2D g2) // draws the player
    {
        /*
        g2.setColor(Color.white);
        g2.fillRect(x,y, gp.tileSize, gp.tileSize);
         */
        BufferedImage image = null;
        image = playerSpaceShip;
        g2.drawImage(image, x,y,gp.tileSize,gp.tileSize,null);
    }

    private void keyUpdate() // moves the player character in a direction based on the input recieved
    {
        if(keyH.upPressed) // makes the character go up
        {
            y-=speed;
        }
        if(keyH.downPressed) // makes the character go down
        {
            y+=speed;
        }
        if(keyH.leftPressed) // makes the character go left
        {
            x-=speed;
        }
        if(keyH.rightPressed) // makes the character go right
        {
            x+=speed;
        }
    }

    private void PlayerBorderCollision() // stops the player character from exiting the game window
    {
        if(x+gp.tileSize >= gp.screenWidth)
            x = gp.screenWidth-gp.tileSize;
        if(x<=0)
            x =0;
        if(y+gp.tileSize>= gp.screenHeight)
            y = gp.screenHeight- gp.tileSize;
        if(y<=0)
            y = 0;
    }
}

