package main;

import background.BackGroundImage;
import entity.Enemy;
import entity.player;

import javax.swing.*;
import java.awt.*;

public class gamePanel extends JPanel implements Runnable{

    //SCREEN SETTINGS
    final int originalTileSize = 16; // 16 x 16 tile
    final int scale = 3; // scales the dimension of the tile to make them more visible on bigger monitors
    public final int tileSize = originalTileSize * scale; // tile size displayed by the game 48
    final int maxScreenCol = 16;
    final int maxScreenRow = 12;
    public final int screenWidth = tileSize * maxScreenCol; // 48 * 16 = 768 pixels
    public final int screenHeight = tileSize * maxScreenRow;// 48 * 12 = 576 pixels

    // fps
    final int fps = 60;

    KeyHandler keyH = new KeyHandler();
    Thread gameThread;
    player Player = new player(this,keyH);
    Enemy enemy = new Enemy(this);
    BackGroundImage backgroundImage = new BackGroundImage(this);
    public gamePanel () // class constructor
    {
        this.setPreferredSize(new Dimension(screenWidth,screenHeight));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
    }
    public void startGameThread() // starts the game by starting the game thread
    {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000/fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        long drawCount = 0;

        while(gameThread != null) // loop repeats continuously as the game runs
        {

            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if(delta >= 1) {
                // update character position
                update();

                // draw the screen with the updated information
                repaint();
                delta--;
                drawCount++;
            }

            if(timer >= 1000000000)
            {
                System.out.println("FPS: " + drawCount);
                drawCount = 0;
                timer = 0;
            }
        }
    }
    public void update() // updates stuff like the player position
    {
        Player.update();
        enemy.update();
    }
    public void paintComponent(Graphics g) // paints stuff on the screen window
    {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D)g; // graphics class with more function
        backgroundImage.draw(g2);
        Player.draw(g2);
        enemy.draw(g2);
        g2.dispose();
    }
}
