package background;

import main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BackGroundImage {
    gamePanel gp;
    public BufferedImage gameBackgroundImage;

    int imgX = 0;
    int imgY = 0;


    public BackGroundImage(gamePanel gp)
    {
        this.gp = gp;
        getBackgroundImage();
    }

    public void getBackgroundImage() // gets the background image to draw on screen
    {
        try{
            gameBackgroundImage = ImageIO.read(getClass().getResourceAsStream("/background/spaceInvadersBackground2.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void draw(Graphics2D g2) // draws the image in the game window
    {
        BufferedImage image = null;
        image = gameBackgroundImage;
        g2.drawImage(image,imgX,imgY,gp.screenWidth, gp.screenHeight,null);
    }
}
