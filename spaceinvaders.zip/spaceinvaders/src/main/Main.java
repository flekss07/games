package main;

import javax.swing.*;

public class Main {
    public static void main(String[] args)
    {
        JFrame window = new JFrame();
        window.setDefaultCloseOperation((JFrame.EXIT_ON_CLOSE)); // esce dal frame se si chiude la finestra
        window.setResizable(false); // disattiva il resize della finestra
        window.setTitle("space invaders"); // imposta il titolo della finestra

        gamePanel GamePanel = new gamePanel(); // gamePanel implementation
        window.add(GamePanel); // adds the gamePanel to the game window

        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        GamePanel.startGameThread();
    }
}
